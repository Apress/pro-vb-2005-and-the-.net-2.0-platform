Option Explicit On
Option Strict On

Public Class Octagon
    Implements IDrawToForm, IDrawToMemory, IDrawToPrinter

    Public Sub Draw() Implements IDrawToForm.Draw
        Console.WriteLine("Rendering to Form!")
    End Sub

    Public Sub RenderToMemory() Implements IDrawToMemory.Draw
        Console.WriteLine("Rendering to memory!")
    End Sub

    Public Sub Print() Implements IDrawToPrinter.Draw
        Console.WriteLine("Rendering to printer!")
    End Sub
End Class
