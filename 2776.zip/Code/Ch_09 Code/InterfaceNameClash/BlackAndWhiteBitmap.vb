Option Explicit On
Option Strict On

' Notice each class method has be defined as Private
' and have been given very non-descript names. 
Public Class BlackAndWhiteBitmap
    Implements IDrawToForm, IDrawToMemory, IDrawToPrinter

    Private Sub X() Implements IDrawToForm.Draw
        ' Insert interesting code...
    End Sub

    Private Sub Y() Implements IDrawToMemory.Draw
        ' Insert interesting code...
    End Sub

    Private Sub Z() Implements IDrawToPrinter.Draw
        ' Insert interesting code...
    End Sub
End Class
