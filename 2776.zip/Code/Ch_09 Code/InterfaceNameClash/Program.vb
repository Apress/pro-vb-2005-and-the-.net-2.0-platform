Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** More Fun with Interfaces *****")

        ' Call members from interface level.
        Dim o As New Octagon

        ' Call IDrawToMemory.Draw()
        Dim iMem As IDrawToMemory
        iMem = CType(o, IDrawToMemory)
        iMem.Draw()

        ' Call IDrawToPrinter.Draw()
        Dim iPrint As IDrawToPrinter
        iPrint = CType(o, IDrawToPrinter)
        iPrint.Draw()

        ' Call IDrawToForm.Draw()
        Dim iForm As IDrawToForm
        iForm = CType(o, IDrawToForm)
        iForm.Draw()

        Dim bwBmp As New BlackAndWhiteBitmap()
        Dim i As IDrawToForm
        i = CType(bwBmp, IDrawToForm)
        i.Draw()
    End Sub
End Module
