Option Explicit On
Option Strict On

Public Interface IDraw3D
    Sub Draw3D()
End Interface
