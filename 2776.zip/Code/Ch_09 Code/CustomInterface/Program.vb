Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Interfaces *****")
        Dim hex As New Hexagon
        Console.WriteLine("Number of Points: {0}", hex.Points)

        ' Circle does not support IPointy!
        Dim c As New Circle()
        Dim itfPointy As IPointy

        Try
            itfPointy = CType(c, IPointy)
            Console.WriteLine("Number of Points: {0}", itfPointy.Points)
        Catch ex As Exception
            Console.WriteLine("{0} does not implement IPointy!", c)
        End Try

        ' See which objects support IPointy.
        Console.WriteLine("Circle implements IPointy?: {0}", TypeOf c Is IPointy)
        Console.WriteLine("Hexagon implements IPointy?: {0}", TypeOf hex Is IPointy)

        ' Make an array of Shape compatable types.
        Dim myShapes() As Shape = {New Hexagon("Fred"), New Circle("Angie"), _
          New ThreeDCircle(), New Triangle("Adam")}

        For Each s As Shape In myShapes
            If TypeOf s Is IPointy Then
                itfPointy = CType(s, IPointy)
                Console.WriteLine("{0} has {1} points.", s.PetName, itfPointy.Points)
            Else
                Console.WriteLine("{0} does not implement IPointy!", s)
            End If
            If TypeOf s Is IDraw3D Then
                DrawIn3D(CType(s, IDraw3D))
            End If
        Next

        ' Can we extract IPointy from an Array of Integers?
        Dim myInts() As Integer = {10, 20, 30}
        Dim i As IPointy = ExtractPointyness(myInts)
        If i Is Nothing Then
            Console.WriteLine("Sorry, this object was not IPoiny compatable")
        End If

        ' Array of IPointy items. 
        Dim pointyThings() As IPointy = {New Hexagon(), New Knife(), _
          New Triangle(), New Fork(), New PitchFork()}
        For Each p As IPointy In pointyThings
            Console.WriteLine("Object has {0} points.", p.Points)
        Next

        Console.ReadLine()
    End Sub

#Region "Helper functions"
    Sub DrawIn3D(ByVal itf3d As IDraw3D)
        Console.WriteLine("-> Drawing IDraw3D compatible type")
        itf3d.Draw3D()
    End Sub
    Function ExtractPointyness(ByVal o As Object) As IPointy
        If TypeOf o Is IPointy Then
            Return CType(o, IPointy)
        Else
            Return Nothing
        End If
    End Function
#End Region

End Module
