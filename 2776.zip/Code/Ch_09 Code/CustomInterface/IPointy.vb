Option Explicit On
Option Strict On

' This interface defines the behavior of "having points."
Public Interface IPointy
    ReadOnly Property Points() As Byte
End Interface
