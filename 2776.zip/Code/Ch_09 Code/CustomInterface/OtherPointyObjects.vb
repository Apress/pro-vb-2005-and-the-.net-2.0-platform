Option Explicit On
Option Strict On

' These classes are just to illustrate the
' role of building an array of interface types. 
Public Class Fork
    Implements IPointy

    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Return 4
        End Get
    End Property
End Class

Public Class Knife
    Implements IPointy

    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Return 1
        End Get
    End Property
End Class

Public Class PitchFork
    Implements IPointy

    Public ReadOnly Property Points() As Byte Implements IPointy.Points
        Get
            Return 3
        End Get
    End Property
End Class