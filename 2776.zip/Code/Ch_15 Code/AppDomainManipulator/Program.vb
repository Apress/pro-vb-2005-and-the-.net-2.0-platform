''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Note!  Be sure to copy CarLibrary.dll to the bin folder
' of this application.  If you don't, you'll get a runtime
' exception!
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
Option Explicit On
Option Strict On

Imports System
Imports System.Reflection

' Don't forget to reference System.Windows.Forms.dll!
Imports System.Windows.Forms

Module Program

    Sub Main()
        Console.WriteLine("***** The Amazing AppDomain app *****")

        Try
            ' Show assemblies in this app domain.
            Dim defaultAD As AppDomain = AppDomain.CurrentDomain()
            MessageBox.Show("Hello")
            PrintAllAssembliesInAppDomain(defaultAD)
            Console.WriteLine()

            ' Programmatically make a new appdomain.
            Dim anotherAD As AppDomain = AppDomain.CreateDomain("SecondAppDomain")
            anotherAD.Load("CarLibrary")
            PrintAllAssembliesInAppDomain(anotherAD)

            ' Hook into DomainUnload event.
            AddHandler anotherAD.DomainUnload, AddressOf anotherAD_DomainUnload

            ' Now unload anotherAD.
            AddHandler defaultAD.ProcessExit, AddressOf defaultAD_ProcessExit
            AppDomain.Unload(anotherAD)
        Catch ex As Exception
            Console.WriteLine("Error: {0}", ex.Message)
        End Try

        Console.ReadLine()
    End Sub

#Region "Helper functions"
    Public Sub PrintAllAssembliesInAppDomain(ByVal ad As AppDomain)
        Dim loadedAssemblies As Assembly() = ad.GetAssemblies()
        Console.WriteLine("***** Here are the assemblies loaded in {0} *****", _
          ad.FriendlyName)

        ' Remember!  We need to import System.Reflection to use
        ' the Assembly type.
        For Each a As Assembly In loadedAssemblies
            Console.WriteLine("-> Name: {0}", a.GetName.Name)
            Console.WriteLine("-> Version: {0}", a.GetName.Version)
        Next
    End Sub

    Public Sub anotherAD_DomainUnload(ByVal sender As Object, ByVal e As EventArgs)
        Console.WriteLine("***** Unloaded anotherAD! *****")
    End Sub

    Private Sub defaultAD_ProcessExit(ByVal sender As Object, ByVal e As EventArgs)
        Console.WriteLine("***** Unloaded defaultAD! *****")
    End Sub
#End Region

End Module
