Option Explicit On
Option Strict On

' Implementing IDisposable.
Class MyResourceWrapper
    Implements IDisposable
    ' The object user should call this method
    ' when they finished with the object.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Clean up unmanaged resources here.
        Console.WriteLine("I am being disposed!")
        ' Dispose other contained disposable objects.
    End Sub
End Class

Module Program
    Sub Main()
        Console.WriteLine("***** A simple Dispose() example *****")
        Console.WriteLine()

        Using rw As New MyResourceWrapper(), _
              rw2 As New MyResourceWrapper()
            ' Use the object, Dispose() automatically called!
        End Using

        Console.ReadLine()
    End Sub
End Module
