Option Explicit On
Option Strict On

#Region " MyResourceWrapper"
Public Class MyResourceWrapper
    Implements IDisposable

    ' Used to determine if Dispose()
    ' has already been called.
    Private disposed As Boolean = False

    Public Sub Dispose() Implements IDisposable.Dispose
        ' Call our helper method.
        ' Specifying "true" signifies that
        ' the object user triggered the clean up.
        CleanUp(True)
        GC.SuppressFinalize(Me)
    End Sub

    Private Sub CleanUp(ByVal disposing As Boolean)
        ' Be sure we have not already been disposed!
        If Not Me.disposed Then
            If disposing Then
                ' Dispose managed resources.
            End If
            ' Clean up unmanaged resources here.
        End If
        disposed = True
    End Sub

    Protected Overrides Sub Finalize()
        ' Call our helper method.
        ' Specifying "false" signifies that
        ' the GC triggered the clean up.

        CleanUp(False)
    End Sub
End Class
#End Region

Module Program
    Sub Main()
        Console.WriteLine("**** Disposable and Finalizable objects *****")
        Console.WriteLine()

        ' Make an object and call Dispose() (this object will not be finalized).
        Dim o As New MyResourceWrapper()
        o.Dispose()

        ' Make object but 'forget' to call Dispose().
        ' the GC will call Finalize when app domain shuts down. 
        Dim o2 As New MyResourceWrapper()

        Console.WriteLine("Press a key to shut down app domain")
        Console.ReadLine()
    End Sub
End Module
