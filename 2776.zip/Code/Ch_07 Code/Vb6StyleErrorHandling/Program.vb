Option Explicit On
Option Strict On

Module Program
    Sub Main()
        On Error GoTo OOPS

        Dim myCar As New Car("Sven", 80)
        For i As Integer = 0 To 10
            myCar.Accelerate(10)
        Next
OOPS:
        ' Use Err object.
        Console.WriteLine("=> Handling error w/ Err object.")
        Console.WriteLine(Err.Description)
        Console.WriteLine(Err.Source)

        Console.WriteLine("=> Handling error w/ exception.")
        Console.WriteLine(Err.GetException().StackTrace)
        Console.WriteLine(Err.GetException().TargetSite)
    End Sub
End Module
