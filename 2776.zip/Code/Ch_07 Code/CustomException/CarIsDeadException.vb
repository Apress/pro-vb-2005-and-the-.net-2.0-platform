Option Explicit On
Option Strict On

#Region "Take one"
' This custom exception describes the details of the car-is-dead condition.
'Public Class CarIsDeadException
'    Inherits ApplicationException

'    Private messageDetails As String

'    Public Sub New()
'    End Sub
'    Public Sub New(ByVal msg As String)
'        messageDetails = msg
'    End Sub

'    ' Override the Exception.Message property.
'    Public Overrides ReadOnly Property Message() As String
'        Get
'            Return String.Format("Car Error Message: {0} ", messageDetails)
'        End Get
'    End Property
'End Class
#End Region

#Region "Take two"
'Public Class CarIsDeadException
'    Inherits ApplicationException
'    Public Sub New()
'    End Sub
'    Public Sub New(ByVal msg As String)
'        MyBase.New(msg)
'    End Sub
'End Class
#End Region

#Region "Take three"
<Serializable()> _
Public Class CarIsDeadException
    Inherits ApplicationException
    Public Sub New()
    End Sub
    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
    Public Sub New(ByVal message As String, ByVal inner As System.Exception)
        MyBase.New(message, inner)
    End Sub
    Protected Sub New(ByVal info As System.Runtime.Serialization.SerializationInfo, _
        ByVal context As System.Runtime.Serialization.StreamingContext)
        MyBase.New(info, context)
    End Sub
End Class
#End Region