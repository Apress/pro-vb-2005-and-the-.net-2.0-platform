Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Methods *****")
        Console.WriteLine()
        ' Pass two Integers by value.
        Console.WriteLine("-> Passing args ByVal")
        Dim x, y As Integer
        x = 10 : y = 20
        Console.WriteLine("{0} + {1} = {2}", x, y, Add(x, y))
        Console.WriteLine("After call x = {0} and y = {1}", x, y)
        Console.WriteLine()

        ' Pass a string by value (although it was prototyped ByRef)
        Console.WriteLine("-> Passing args ByVal, even though ByRef is expected")
        Dim msg As String = "Hello from Main!"
        PrintMessage((msg)) ' Remove extra () to pass ByRef.
        Console.WriteLine("After call msg = {0}", msg)
        Console.WriteLine()

        ' Call method with optional args.
        Console.WriteLine("-> Passing Optional args")
        PrintFormattedMessage("Call One")
        PrintFormattedMessage("Call Two", True, 5, ConsoleColor.Yellow)
        ' Print this message in suppled case, one time, in gray.
        PrintFormattedMessage("Call Three", , , ConsoleColor.Gray)
        ' Same as above, but cleaner!
        PrintFormattedMessage("Call Four", textColor:=ConsoleColor.Gray)
        Console.WriteLine()

        ' Call w/ ParamArray (or not)
        Console.WriteLine("-> Passing args via ParamArray")
        Console.WriteLine(CalculateAverage(10, 11, 12, 44))
        Dim data() As Integer = {22, 33, 44, 55}
        Console.WriteLine(CalculateAverage(data))
        Console.WriteLine()

        ' Invoke method with static local variable.
        Console.WriteLine("-> Calling method w/ static local variable")
        For i As Integer = 0 To 10
            PrintLocalCounter()
        Next
        Console.WriteLine()
        Console.WriteLine()

        ' Call overloaded method.
        Console.WriteLine("-> Calling overloaded Add()")
        ' Calls Integer version of Add()
        Console.WriteLine(Add(10, 10))
        ' Calls Long verson of Add()  
        Console.WriteLine(Add(900000000000, 900000000000))
        ' Calls Double version of Add()
        Console.WriteLine(Add(4.3, 4.4))
        Console.ReadLine()
    End Sub
End Module

