Option Explicit On
Option Strict On

Module HelperFunctions
    Sub PrintMessage(ByRef msg As String)
        Console.WriteLine("Your message is: {0}", msg)

        ' Try to set string to new value.
        msg = "Thank you for calling this method"
    End Sub
    Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Dim answer As Integer = x + y
        ' Try to set the params to a new value.
        x = 22 : y = 30
        Return answer
    End Function
    Public Function Add(ByVal x As Double, ByVal y As Double) As Double
        Return x + y
    End Function
    Public Function Add(ByVal x As Long, ByVal y As Long) As Long
        Return x + y
    End Function
    Function CalculateAverage(ByVal ParamArray itemsToAvg() As Integer) As Double
        Dim itemCount As Integer = UBound(itemsToAvg)
        Dim result As Integer
        For i As Integer = 0 To itemCount
            result += itemsToAvg(i)
        Next
        Return result / itemCount
    End Function
    Sub PrintFormattedMessage(ByVal msg As String, _
        Optional ByVal upperCase As Boolean = False, _
        Optional ByVal timesToRepeat As Integer = 0, _
        Optional ByVal textColor As ConsoleColor = ConsoleColor.Green)

        ' Store current console forground color.
        Dim fGroundColor As ConsoleColor = Console.ForegroundColor

        ' Set Console Text color.
        Console.ForegroundColor = textColor

        ' Print mesage in correct case x number of times.
        For i As Integer = 0 To timesToRepeat
            Console.WriteLine(msg)
        Next

        ' Reset current console forground color.
        Console.ForegroundColor = fGroundColor
    End Sub
    Sub PrintLocalCounter()
        ' Note the Static keyword.
        Static Dim localCounter As Integer
        localCounter += 1
        Console.Write("{0} ", localCounter)
    End Sub
End Module
