Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Arrays *****")
        Console.WriteLine()

        ' Create an array using VB 6.0 style syntax.
        Console.WriteLine("* Simple array of Strings *")
        Dim myStrs(2) As String
        myStrs(0) = "Cerebus"
        myStrs(1) = "Jaka"
        myStrs(2) = "Astoria"
        For Each s As String In myStrs
            Console.WriteLine(s)
        Next
        Console.WriteLine()

        ' Get bounds / Length of myStrs array.
        Console.WriteLine("* Bounds and Length *")
        Console.WriteLine("Upper bound of myStrs is: {0}", UBound(myStrs))
        Console.WriteLine("Length of myStrs is: {0}", myStrs.Length)
        Console.WriteLine()

        ' An array of 3 Integers w/ curly bracket syntax.
        Console.WriteLine("* Simple array of Integers *")
        Dim myInts() As Integer = {100, 200, 300}
        For Each i As Integer In myInts
            Console.WriteLine(i)
        Next
        Console.WriteLine()

        ' An array of Objects can be anything at all. 
        Console.WriteLine("* Simple array of Objects *")
        Dim myObjects(3) As Object
        myObjects(0) = 10
        myObjects(1) = False
        myObjects(2) = New DateTime(1969, 3, 24)
        myObjects(3) = "Form & Void"
        For Each obj As Object In myObjects
            Console.WriteLine("Type: {0}, Value: {1}", obj.GetType(), obj)
        Next

        ' An array with specific lower bounds.
        Console.WriteLine("* Array with set lower bound*")
        ' Length of each dimention
        Dim myLengths() As Integer = {3}
        Dim myBounds() As Integer = {5}
        Dim mySpecialArray As Array = _
           Array.CreateInstance(GetType(Integer), myLengths, myBounds)
        Console.WriteLine("Lower Bound: {0}", LBound(mySpecialArray))
        Console.WriteLine("Upper Bound: {0}", UBound(mySpecialArray))
        Console.WriteLine()

        ' Redemention an array.
        Console.WriteLine("* ReDim / Preserve *")
        Dim myValues(9) As Integer
        For i As Integer = 0 To 9
            myValues(i) = i
        Next
        For i As Integer = 0 To UBound(myValues)
            Console.Write("{0} ", myValues(i))
        Next
        Console.WriteLine()
        ReDim Preserve myValues(15)
        For i As Integer = 9 To UBound(myValues)
            myValues(i) = i
        Next
        For i As Integer = 0 To UBound(myValues)
            Console.Write("{0} ", myValues(i))
        Next
        Console.WriteLine()
        Console.WriteLine()

        Console.WriteLine("* A 7 * 7 Array *")
        Dim myMatrix(6, 6) As Integer  ' makes a 7x7 array 
        ' Populate array.
        Dim k As Integer, j As Integer
        For k = 0 To 6
            For j = 0 To 6
                myMatrix(k, j) = k * j
            Next j
        Next k
        ' Show array.
        For k = 0 To 6
            For j = 0 To 6
                Console.Write(myMatrix(k, j) & "  ")
            Next j
            Console.WriteLine()
        Next k
        Console.WriteLine()

        ' Initialize items at startup.
        Console.WriteLine("* Fun with System.Array *")
        Dim gothicBands() _
            As String = {"Tones on Tail", "Bauhaus", "Sisters of Mercy"}
        ' Print out names in declared order.
        Console.WriteLine(" -> " & "Here is the array:")
        For i As Integer = 0 To gothicBands.GetUpperBound(0)
            ' Print a name
            Console.Write(gothicBands(i) & " ")
        Next
        Console.WriteLine()
        ' Reverse them...
        Array.Reverse(gothicBands)
        Console.WriteLine(" -> " & "The reversed array")
        ' ... and print them.
        For i As Integer = 0 To gothicBands.GetUpperBound(0)
            ' Print a name
            Console.Write(gothicBands(i) & " ")
        Next
        Console.WriteLine()
        ' Clear out all but the final member.
        Console.WriteLine(" -> " & "Cleared out all but one...")
        Array.Clear(gothicBands, 1, 2)
        For i As Integer = 0 To gothicBands.GetUpperBound(0)
            ' Print a name
            Console.Write(gothicBands(i) & " ")
        Next
        Console.WriteLine()
    End Sub
End Module
