Option Explicit On
Option Strict On

' Build an alias to System.Enum
Imports DotNetEnum = System.Enum

Enum EmpType As Byte
    Manager = 102
    Grunt       ' = 103
    Contractor  ' = 104
    VP          ' = 105
End Enum

Module Program
    ' Enums as parameters.
    Public Sub AskForBonus(ByVal e As EmpType)
        Select Case (e)
            Case EmpType.Contractor
                Console.WriteLine("You already get enough cash...")
            Case EmpType.Grunt
                Console.WriteLine("You have got to be kidding...")
            Case EmpType.Manager
                Console.WriteLine("How about stock options instead?")
            Case EmpType.VP
                Console.WriteLine("VERY GOOD, Sir!")
        End Select
    End Sub

    Sub Main()
        Console.WriteLine("**** Fun with Enums *****")
        Console.WriteLine()

        ' Make a contractor type.
        Dim fred As EmpType
        fred = EmpType.Contractor
        AskForBonus(fred)
        ' Print out the data type used to store the values?
        Console.WriteLine("EmpType uses a {0} for storage", _
            DotNetEnum.GetUnderlyingType(fred.GetType()))
        Console.WriteLine("Fred is a {0}", fred.ToString())

        ' Get all stats for EmpType.
        Dim obj As Array = DotNetEnum.GetValues(fred.GetType())
        Console.WriteLine("This enum has {0} members.", obj.Length)
        Console.WriteLine()

        ' Now show the string name and associated value.
        Dim e As EmpType
        For Each e In obj
            Console.Write("String name: {0}", DotNetEnum.Format(fred.GetType(), e, "G"))
            Console.Write(" ({0})", DotNetEnum.Format(fred.GetType(), e, "D"))
            Console.WriteLine(" hex: {0}", DotNetEnum.Format(fred.GetType(), e, "X"))
        Next
        Console.WriteLine()

        ' Does EmpType have a SalesPerson value?
        If (DotNetEnum.IsDefined(fred.GetType(), "SalesPerson")) Then
            Console.WriteLine("Yep, we have sales people.")
        Else
            Console.WriteLine("No, we have no profits....")
        End If
    End Sub
End Module

