Option Explicit On
Option Strict On

#Region "Point structure"
Structure Point
    Public x, y As Integer
    Public Sub Display()
        Console.WriteLine("{0}, {1}", x, y)
    End Sub
    Public Sub Increment()
        x += 1 : y += 1
    End Sub
    Public Sub Decrement()
        x -= 1 : y -= 1
    End Sub
    Public Function PointAsHexString() As String
        Return String.Format("{0:x}, {1:x}", x, y)
    End Function
End Structure
#End Region

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Structs *****")
        ' Create a Point
        Dim myPoint As Point
        myPoint.x = 100
        myPoint.y = 200
        myPoint.Display()

        ' Increase value of Point
        myPoint.Increment()
        myPoint.Display()
        Console.WriteLine("Value of Point in hex: {0}", myPoint.PointAsHexString())
    End Sub ' myPoint destroyed here!
End Module
