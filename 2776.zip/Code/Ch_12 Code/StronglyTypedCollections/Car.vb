Option Explicit On
Option Strict On

' This is just to test the custom Car collection.
Public Class Car
End Class
