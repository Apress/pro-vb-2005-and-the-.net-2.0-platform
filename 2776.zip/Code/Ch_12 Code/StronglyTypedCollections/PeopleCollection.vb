Option Explicit On
Option Strict On

Public Class PeopleCollection
    Implements IEnumerable
    Private arPeople As ArrayList = New ArrayList()

    Public Function GetPerson(ByVal pos As Integer) As Person
        Return CType(arPeople(pos), Person)
    End Function

    Public Sub AddPerson(ByVal p As Person)
        arPeople.Add(p)
    End Sub

    Public Sub ClearPeople()
        arPeople.Clear()
    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return arPeople.Count
        End Get
    End Property

    Public Function GetEnumerator() As IEnumerator _
    Implements IEnumerable.GetEnumerator
        Return arPeople.GetEnumerator()
    End Function
End Class
