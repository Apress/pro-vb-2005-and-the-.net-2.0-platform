Option Explicit On
Option Strict On

' This generic delegate can point to any method
' taking a single argument (specified at the time
' of creation).
Public Delegate Sub MyGenericDelegate(Of T)(ByVal arg As T)

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with generic delegates *****")
        Console.WriteLine()

        ' Make instance of delegate pointing to method taking an
        ' integer.
        Dim d As New MyGenericDelegate(Of Integer)(AddressOf IntegerTarget)
        d(100)

        ' Now pointing to a method taking a string.
        Dim d2 As New MyGenericDelegate(Of String)(AddressOf StringTarget)
        d2("Cool!")
    End Sub

    Public Sub IntegerTarget(ByVal arg As Integer)
        Console.WriteLine("You passed me a {0} with the value of {1}", _
          arg.GetType().Name, arg)
    End Sub

    Public Sub StringTarget(ByVal arg As String)
        Console.WriteLine("You passed me a {0} with the value of {1}", _
          arg.GetType().Name, arg)
    End Sub
End Module
