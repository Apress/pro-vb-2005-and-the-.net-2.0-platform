Option Explicit On
Option Strict On

#Region "Helper class"
Class DatabaseReader
    ' Nullable data fields.
    Public numbericValue As Nullable(Of Integer)
    Public boolValue As Nullable(Of Boolean) = True

    ' Note the nullable return type. 
    Public Function GetIntFromDatabase() As Nullable(Of Integer)
        Return numbericValue
    End Function

    ' Note the nullable return type. 
    Public Function GetBoolFromDatabase() As Nullable(Of Boolean)
        Return boolValue
    End Function
End Class
#End Region

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Nullable Data *****")
        Console.WriteLine()
        Dim dr As New DatabaseReader()

        ' Get int from 'database'.
        Dim i As Nullable(Of Integer) = dr.GetIntFromDatabase()
        If (i.HasValue) Then
            Console.WriteLine("Value of 'i' is: {0}", i.Value)
        Else
            Console.WriteLine("Value of 'i' is undefined.")
        End If

        ' Get bool from 'database'.
        Dim b As Nullable(Of Boolean) = dr.GetBoolFromDatabase()
        If (b.HasValue) Then
            Console.WriteLine("Value of 'b' is: {0}", b.Value)
        Else
            Console.WriteLine("Value of 'b' is undefined.")
        End If
        Console.ReadLine()
    End Sub
End Module
