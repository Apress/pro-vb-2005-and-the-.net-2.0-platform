' A simple VB 2005 application.
Imports System

' Don't need this anymore.
' Imports System.Windows.Forms

Module TestApp
    Sub Main()
        Console.WriteLine("Testing! 1, 2, 3")

        ' Don't need this anymore either.
        ' MessageBox.Show("Hello...");
        
        ' Exercise the HelloMessage class! 
        Dim h As New HelloMessage()
        h.Speak()
    End Sub 
End Module