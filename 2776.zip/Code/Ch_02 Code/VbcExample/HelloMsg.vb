' The HelloMessage class
Imports System 
Imports System.Windows.Forms 

Class HelloMessage
    Sub Speak()
        MessageBox.Show("Hello Again") 
    End Sub 
End Class 
