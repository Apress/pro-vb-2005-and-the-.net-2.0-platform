Option Explicit On
Option Strict On

Imports Vb6ComCarServer

Module Program
    ' Create the COM class using 
    ' early binding.
    Public WithEvents myCar As New CoCar()

    Sub Main()
        Console.WriteLine("***** CoCar Client App *****")

        ' Call the Create() method.
        myCar.Create(50, 10, CarType.BMW)

        ' Set name of driver.
        Dim itf As IDriverInfo
        itf = CType(myCar, IDriverInfo)
        itf.driverName = "Fred"
        Console.WriteLine("Drive is named: {0}", itf.driverName)

        ' Print type of car.
        Console.WriteLine("Your car is a {0}.", myCar.CarMake())
        Console.WriteLine()

        ' Get the Engine and print name of a Cylinders.
        Dim eng As Engine = myCar.GetEngine()

        Console.WriteLine("Your Cylinders are named:")
        Dim names() As String = CType(eng.GetCylinders(), String())
        For Each s As String In names
            Console.WriteLine(s)
        Next
        Console.WriteLine()

        ' Speed up car to trigger event.
        For i As Integer = 0 To 3
            myCar.SpeedUp()
        Next

        UseCar()
    End Sub

    Private Sub myCar_BlewUp() Handles myCar.BlewUp
        Console.WriteLine("***** Ek!  Car is doomed...! *****")
    End Sub

    Sub UseCar()
        Dim c As New CoCarClass()

        ' This proprety is a member of IDriverInfo.
        c.driverName = "Mary"

        ' This method is a member of _CoCar.
        c.SpeedUp()
    End Sub
End Module
