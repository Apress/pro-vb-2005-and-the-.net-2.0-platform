Option Explicit On
Option Strict On

' We need this to obtain the necessary
' interop attributes. 
Imports System.Runtime.InteropServices

<ClassInterface(ClassInterfaceType.AutoDual)> _
<Guid("88737214-2E55-4d1b-A354-7A538BD9AB2D")> _
Public Class DotNetCalc
    Public Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x + y
    End Function
    Public Function Subtract(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x - y
    End Function
End Class
