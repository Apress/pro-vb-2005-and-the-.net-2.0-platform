Option Explicit On
Option Strict On

<ComClass(DotNetPerson.ClassId, DotNetPerson.InterfaceId, DotNetPerson.EventsId)> _
Public Class DotNetPerson

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "ec2a6ec2-a681-41a1-a644-30c16c7409a9"
    Public Const InterfaceId As String = "ea905f17-5f7f-4958-b8c6-a95f419063a8"
    Public Const EventsId As String = "57c3d0e3-9e15-4b6a-a96e-b4c6736c7b6d"
#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public Function GetMessage() As String
        Return "I am alive..."
    End Function

End Class


