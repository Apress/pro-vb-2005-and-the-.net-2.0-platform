' This type will be placed
' within a *.netmodule binary,
' and it thus part of a multifile
' Assembly. 
Namespace AirVehicles
	Public Class Ufo
		Public Sub AbductHuman()
			Console.WriteLine("Resistance is futile")
		End Sub
	End Class 
End Namespace
