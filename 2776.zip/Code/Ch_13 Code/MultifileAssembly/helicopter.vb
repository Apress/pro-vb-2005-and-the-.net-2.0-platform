' This type will be in the 
' primary module of the multifile
' assembly, therefore this assembly
' will contain the assembly manifest.
Namespace AirVehicles
	Public Class Helicopter
		Public Sub TakeOff()
			Console.WriteLine("Helicopter taking off!")
		End Sub
	End Class 
End Namespace
