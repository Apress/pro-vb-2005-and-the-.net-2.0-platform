Option Explicit On
Option Strict On

Module Program

    Sub Main()
        Console.WriteLine("***** Fun with Shared Data *****")
        Dim s1 As New SavingsAccount(50)
        Dim s2 As New SavingsAccount(100)

        ' Get and Set interest rate at object level.
        Console.WriteLine("Interest Rate is: {0} ", s1.GetInterestRateObj())
        s2.SetInterestRateObj(0.08)

        ' Make new object, this does NOT 'reset' the interest rate.
        Dim s3 As New SavingsAccount(10000.75)
        Console.WriteLine("Interest Rate is: {0} ", SavingsAccount.GetInterestRate())

        SavingsAccount.SetInterestRate(0.09)
        ' All three lines print out "Interest Rate is: 0.09"
        Console.WriteLine("Interest Rate is: {0}", s1.GetInterestRateObj())
        Console.WriteLine("Interest Rate is: {0}", s2.GetInterestRateObj())
        Console.WriteLine("Interest Rate is: {0}", SavingsAccount.GetInterestRate())

        Console.ReadLine()
    End Sub

End Module
