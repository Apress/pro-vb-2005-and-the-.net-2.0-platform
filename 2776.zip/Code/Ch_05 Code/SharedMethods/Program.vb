Option Explicit On
Option Strict On

Module Program

    Sub Main()
        Console.WriteLine("***** Shared Methods *****")
        For i As Integer = 0 To 5
            Console.WriteLine(Teenager.Complain())
        Next

        ' This will only work with the default compiler settings!
        ' See Chatpter 5 on details regarding this odd VB-ism. 
        Dim bob As New Teenager
        Console.WriteLine(bob.Complain())
    End Sub

End Module
