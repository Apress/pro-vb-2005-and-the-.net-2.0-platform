Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Class Types *****")

        ' Allocate and configure a Car object, field by field.
        Console.WriteLine(vbLf + "-> Making a Car object")
        Dim myCar As Car = New Car()
        myCar.petName = "Sven"
        myCar.currSpeed = 10

        ' Speed up the car a few times and print out the
        ' new state. 
        For i As Integer = 0 To 10
            myCar.SpeedUp(5)
            myCar.PrintState()
        Next

        Console.WriteLine(vbLf + "-> Making a Motorcycle object")

        ' Make a Motorcycle.
        Dim c As New Motorcycle(5)
        c.SetDriverName("Tiny")
        c.PopAWheely()
        Console.WriteLine("Rider name is {0}", c.driverName)

        ' Just to keep command window on the screen.
        Console.ReadLine()
    End Sub
End Module
