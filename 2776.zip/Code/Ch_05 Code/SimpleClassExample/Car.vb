Option Explicit On
Option Strict On

Public Class Car
    ' The 'state' of the Car.
    Public petName As String
    Public currSpeed As Integer

    ' A custom default constructor.
    Public Sub New()
        petName = "Chuck"
        currSpeed = 10
    End Sub

    ' Here, current speed will receive the
    ' default value of an Integer (zero).
    Public Sub New(ByVal pn As String)
        petName = pn
    End Sub

    Public Sub New(ByVal pn As String, ByVal cs As Integer)
        petName = pn
        currSpeed = cs
    End Sub

    ' The functionality of the Car.
    Public Sub PrintState()
        Console.WriteLine("{0} is going {1} MPH.", _
            petName, currSpeed)
    End Sub

    ' Increase the speed of the Car by some 
    ' amount.
    Public Sub SpeedUp(ByVal delta As Integer)
        currSpeed += delta
    End Sub
End Class
