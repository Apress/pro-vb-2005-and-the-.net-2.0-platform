Option Explicit On
Option Strict On

Partial Public Class Employee
    ' Constructors
    Sub New()
    End Sub
    Sub New(ByVal name As String, ByVal age As Integer, _
      ByVal id As Integer, ByVal pay As Single, _
      ByVal ssn As String)
        empName = name
        empAge = age
        empID = id
        empSSN = ssn
        currPay = pay
    End Sub
    Shared Sub New()
        companyName = "Intertech Training"
    End Sub

#Region "Properties"
    ' Properties
    ' Now as a readonly property.
    Public ReadOnly Property SocialSecurityNumber() As String
        Get
            Return empSSN
        End Get
    End Property
    Public Shared Property Company() As String
        Get
            Return companyName
        End Get
        Set(ByVal value As String)
            companyName = value
        End Set
    End Property
    Public Property Name() As String
        Get
            Return empName
        End Get
        Set(ByVal value As String)
            empName = value
        End Set
    End Property
    Public Property Age() As Integer
        Get
            Return empAge
        End Get
        Set(ByVal value As Integer)
            empAge = value
        End Set
    End Property
    Public Property ID() As Integer
        Get
            Return empID
        End Get
        Set(ByVal value As Integer)
            empID = value
        End Set
    End Property
    Public Property Pay() As Single
        Get
            Return currPay
        End Get
        Set(ByVal value As Single)
            currPay = value
        End Set
    End Property
#End Region

End Class
