Option Explicit On
Option Strict On

Module Program

    Sub Main()
        Console.WriteLine("***** Fun with Encapsulation *****")
        Console.WriteLine("These folks work at {0}", Employee.Company)

        Dim emp As New Employee("Marvin", 29, 456, 30000, "111-11-1111")
        emp.GiveBonus(1000)
        emp.Age = emp.Age + 1
        emp.DisplayStats()

        ' Set and Get the Name property.
        emp.Name = "Marv"
        Console.WriteLine("Employee is named: {0}", emp.Name)
        Console.ReadLine()

        ' Increment age via properties. 
        Dim joe As New Employee()
        joe.Age = joe.Age + 1

    End Sub

End Module
