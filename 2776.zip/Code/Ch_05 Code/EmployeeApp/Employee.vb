Option Explicit On
Option Strict On

''' <summary>
''' This is the Employee class.
''' It is the base class in our hierarchy.
''' </summary>
''' <remarks></remarks>
Partial Public Class Employee
    ' Field data.
    Private empName As String
    Private empID As Integer
    Private currPay As Single
    Private empAge As Integer
    Private empSSN As String
    Private Shared companyName As String

    ' Members.
    ''' <summary>
    ''' Increase the pay of the employee.
    ''' </summary>
    ''' <param name="amount"></param>
    ''' <remarks></remarks>
    Sub GiveBonus(ByVal amount As Single)
        currPay += amount
    End Sub

    ''' <summary>
    ''' Print out the state of the current object.
    ''' </summary>
    ''' <remarks></remarks>
    Sub DisplayStats()
        Console.WriteLine("Name: {0}", empName)
        Console.WriteLine("Age: {0}", empAge)
        Console.WriteLine("SSN: {0}", empSSN)
        Console.WriteLine("ID: {0}", empID)
        Console.WriteLine("Pay: {0}", currPay)
    End Sub
End Class
