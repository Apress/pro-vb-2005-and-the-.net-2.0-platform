Option Explicit On
Option Strict On

' Change this to a number other
' than 0 to change output of SomeMethod()
#Const MONO_BUILD = 0

Class SomeClass
    Public Sub SomeMethod()
#If MONO_BUILD Then
    Console.WriteLine("Compiling under Mono!")
#Else
    Console.WriteLine("Compiling under Microsoft .NET")
#End If
    End Sub
End Class
