Option Explicit On
Option Strict On

' The DEBUG constant was disabled in the My Project
' property page, but defined and enabled in this file.

' Set to 0 to skip the code within
' #If / #End If
#Const DEBUG = 1

Module Program

    Sub Main()
        ' This code will only execute if the project is
        ' compiled as a Debug build.
#If DEBUG Then
        Console.WriteLine("***** In Debug Mode! *****")
        Console.WriteLine("App directory: {0}", _
            Environment.CurrentDirectory)
        Console.WriteLine("Box: {0}", _
            Environment.MachineName)
        Console.WriteLine("OS: {0}", _
            Environment.OSVersion)
        Console.WriteLine(".NET Version: {0}", _
            Environment.Version)
#End If

        ' Based on MONO_BUILD symbol, this will print out 
        ' a different message.
        Dim o As New SomeClass()
        o.SomeMethod()

    End Sub

End Module
