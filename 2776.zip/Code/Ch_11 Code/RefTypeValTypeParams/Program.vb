Option Explicit On
Option Strict On

#Region "Person class"
Class Person
    Public fullName As String
    Public age As Integer
    Public Sub New(ByVal n As String, ByVal a As Integer)
        fullName = n
        age = a
    End Sub
    Public Sub New()
    End Sub
    Public Sub PrintInfo()
        Console.WriteLine("{0} is {1} years old", fullName, age)
    End Sub
End Class

#End Region

Module Program
    Sub Main()
        ' Passing ref types by value.
        'Console.WriteLine("***** Passing Person object by value *****")
        'Dim fred As Person = New Person("Fred", 12)
        'Console.WriteLine("Before by value call, Person is:")
        'fred.PrintInfo()
        'SendAPersonByValue(fred)
        'Console.WriteLine("After by value call, Person is:")
        'fred.PrintInfo()

        ' Passing ref-types by ref.
        Console.WriteLine("***** Passing Person object by reference *****")
        Dim mel As New Person("Mel", 23)
        Console.WriteLine("Before by ref call, Person is:")
        mel.PrintInfo()
        SendAPersonByReference(mel)
        Console.WriteLine("After by ref call, Person is:")
        mel.PrintInfo()

        Console.ReadLine()
    End Sub

    Sub SendAPersonByValue(ByVal p As Person)
        ' Change the age of 'p'?
        p.age = 99

        ' Will the caller see this reassignment?
        p = New Person("Nikki", 999)
    End Sub

    Sub SendAPersonByReference(ByRef p As Person)
        ' Change some data of 'p'.
        p.age = 555

        ' 'p' is now pointing to a new object on the heap!
        p = New Person("Nikki", 999)
    End Sub

End Module
