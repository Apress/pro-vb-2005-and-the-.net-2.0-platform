Option Explicit On
Option Strict On

Public Structure MyPoint
    Implements IComparable
    Private x As Integer, y As Integer
    Public Sub New(ByVal xPos As Integer, ByVal yPos As Integer)
        x = xPos
        y = yPos
    End Sub

#Region "Overloaded Binary Operators"
    ' overloaded operator +.
    Public Shared Operator +(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As MyPoint
        Return New MyPoint(p1.x + p2.x, p1.y + p2.y)
    End Operator
    ' overloaded operator -.
    Public Shared Operator -(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As MyPoint
        Return New MyPoint(p1.x - p2.x, p1.y - p2.y)
    End Operator
    ' Now let's overload the = and <> operators.
    Public Shared Operator =(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return p1.Equals(p2)
    End Operator
    Public Shared Operator <>(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return Not p1.Equals(p2)
    End Operator

    ' And the comparison ops. 
    Public Shared Operator <(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return (p1.CompareTo(p2) < 0)
    End Operator
    Public Shared Operator >(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return (p1.CompareTo(p2) > 0)
    End Operator
    Public Shared Operator <=(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return (p1.CompareTo(p2) <= 0)
    End Operator
    Public Shared Operator >=(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As Boolean
        Return (p1.CompareTo(p2) >= 0)
    End Operator
#End Region

#Region "System.Object overrides"
    Public Overrides Function Equals(ByVal o As Object) As Boolean
        If TypeOf o Is MyPoint Then
            If Me.ToString() = o.ToString() Then
                Return True
            End If
        End If
        Return False
    End Function
    Public Overrides Function GetHashCode() As Integer
        Return Me.ToString().GetHashCode()
    End Function
    Public Overrides Function ToString() As String
        Return String.Format("[{0}, {1}]", Me.x, Me.y)
    End Function
#End Region

#Region "IComparable Members"
    Public Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
        If TypeOf obj Is MyPoint Then
            Dim p As MyPoint = CType(obj, MyPoint)
            If Me.x > p.x AndAlso Me.y > p.y Then
                Return 1
            End If
            If Me.x < p.x AndAlso Me.y < p.y Then
                Return -1
            Else
                Return 0
            End If
        Else
            Throw New ArgumentException()
        End If
    End Function
#End Region

#Region "'Normal' Add() and Subtract() methods"
    ' Operator + via Add()
    Public Shared Function Add(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As MyPoint
        Return p1 + p2
    End Function
    ' Operator - via Subtract()
    Public Shared Function Subtract(ByVal p1 As MyPoint, ByVal p2 As MyPoint) As MyPoint
        Return p1 - p2
    End Function
#End Region

End Structure
