Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Overloaded Operators *****")
        Console.WriteLine()

        ' Make two MyPoints
        Dim ptOne As MyPoint = New MyPoint(100, 100)
        Dim ptTwo As MyPoint = New MyPoint(40, 40)
        Console.WriteLine("ptOne = {0}", ptOne)
        Console.WriteLine("ptTwo = {0}", ptTwo)
        Console.WriteLine()

        ' Use operator + or Add().
        Console.WriteLine("ptOne + ptTwo: {0} ", ptOne + ptTwo)
        Console.WriteLine("MyPoint.Add(ptOne, ptTwo): {0} ", MyPoint.Add(ptOne, ptTwo))
        Console.WriteLine()

        ' Use operator - or Subtract().
        Console.WriteLine("ptOne - ptTwo: {0} ", ptOne - ptTwo)
        Console.WriteLine("MyPoint.Subtract(ptOne, ptTwo): {0} ", MyPoint.Subtract(ptOne, ptTwo))
        Console.WriteLine()

        ' Use various comparision operators. 
        Console.WriteLine("ptOne = ptTwo : {0}", ptOne = ptTwo)
        Console.WriteLine("ptOne <> ptTwo : {0}", ptOne <> ptTwo)
        Console.WriteLine("ptOne < ptTwo : {0}", ptOne < ptTwo)
        Console.WriteLine("ptOne > ptTwo : {0}", ptOne > ptTwo)
        Console.ReadLine()
    End Sub
End Module
