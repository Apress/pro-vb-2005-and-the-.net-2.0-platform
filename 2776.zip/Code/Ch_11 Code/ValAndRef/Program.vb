Option Explicit On
Option Strict On

#Region "Helper types"
' Structures are value types!
'Structure MyPoint
'    Public x, y As Integer
'End Structure

' Classes are always reference types.
Class MyPoint
    Public x, y As Integer
End Class ' Now a class!

Class ShapeInfo
    Public infoString As String
    Public Sub New(ByVal info As String)
        infoString = info
    End Sub
End Class

Structure MyRectangle
    ' The MyRectangle structure contains a reference type member.
    Public rectInfo As ShapeInfo

    Public top, left, bottom, right As Integer

    Public Sub New(ByVal info As String)
        rectInfo = New ShapeInfo(info)
        top = 10 : left = 10
        bottom = 10 : right = 100
    End Sub
End Structure
#End Region

Module Program
    Sub Main()
        Console.WriteLine("***** Value Types / Reference Types *****")
        Console.WriteLine("-> Creating p1")
        Dim p1 As New MyPoint()
        p1.x = 100
        p1.y = 100
        Console.WriteLine("-> Assigning p2 to p1")
        Dim p2 As MyPoint = p1

        ' Here is p1.
        Console.WriteLine("p1.x = {0}", p1.x)
        Console.WriteLine("p1.y = {0}", p1.y)

        ' Here is p2.
        Console.WriteLine("p2.x = {0}", p2.x)
        Console.WriteLine("p2.y = {0}", p2.y)

        ' Change p2.x. This will NOT change p1.x.
        Console.WriteLine("-> Changing p2.x to 900")
        p2.x = 900

        ' Print again.
        Console.WriteLine("-> Here are the X values again...")
        Console.WriteLine("p1.x = {0}", p1.x)
        Console.WriteLine("p2.x = {0}", p2.x)

        Console.WriteLine()

        ' Create the first MyRectangle.
        Console.WriteLine("-> Creating r1")
        Dim r1 As New MyRectangle("This is my first rect")

        ' Now assign a new MyRectangle to r1.
        Console.WriteLine("-> Assigning r2 to r1")
        Dim r2 As MyRectangle
        r2 = r1

        ' Change values of r2.
        Console.WriteLine("-> Changing all values of r2")
        r2.rectInfo.infoString = "This is new info!"
        r2.bottom = 4444

        ' Print values
        Console.WriteLine("-> Values after change:")
        Console.WriteLine("-> r1.rectInfo.infoString: {0}", r1.rectInfo.infoString)
        Console.WriteLine("-> r2.rectInfo.infoString: {0}", r2.rectInfo.infoString)
        Console.WriteLine("-> r1.bottom: {0}", r1.bottom)
        Console.WriteLine("-> r2.bottom: {0}", r2.bottom)

        Console.ReadLine()
    End Sub

#Region "These methods are not called by the program...just here for illustrative reasons"
    ' Integers are value types!
    Public Sub SomeMethod()
        Dim i As Integer = 0
        Console.WriteLine("Value of I is: {0}", i)
    End Sub  ' i is popped off the stack here!

    ' Assigning two intrinsic value types results in
    ' two independent variables on the stack.
    Public Sub SomeOtherMethod()
        Dim i As Integer = 99
        Dim k As Integer = i

        ' After the following assignment, 'i' is still 99.
        k = 8732
    End Sub
#End Region

End Module
