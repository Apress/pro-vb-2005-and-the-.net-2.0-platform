Option Explicit On
Option Strict On

Public Class Car
    ' Our delegate types.
    Public Delegate Sub AboutToBlow(ByVal msg As String)
    Public Delegate Sub Exploded(ByVal msg As String)

    ' Because delegates are simply classes, we can create
    ' member variables.
    Private almostDeadList As AboutToBlow
    Private explodedList As Exploded

    ' Now with type-safe multicasting!
    Public Sub OnAboutToBlow(ByVal clientMethod As AboutToBlow)
        almostDeadList = CType(System.Delegate.Combine(almostDeadList, _
          clientMethod), AboutToBlow)
    End Sub
    Public Sub OnExploded(ByVal clientMethod As Exploded)
        explodedList = CType(System.Delegate.Combine(explodedList, _
          clientMethod), Exploded)
    End Sub

    ' To remove a target from the list.
    Public Sub RemoveAboutToBlow(ByVal clientMethod As AboutToBlow)
        almostDeadList = CType(System.Delegate.Remove(almostDeadList, _
          clientMethod), AboutToBlow)
    End Sub

    Public Sub RemoveExploded(ByVal clientMethod As Exploded)
        explodedList = CType(System.Delegate.Remove(explodedList, _
          clientMethod), Exploded)
    End Sub

    ' Constant for maximum speed.
    Public Const maxSpeed As Integer = 100

    'Internal state data.
    Private currSpeed As Integer
    Private petName As String

    'Is the car still operational?
    Private carIsDead As Boolean

    'A car has a radio.
    Private theMusicBox As Radio = New Radio

    ' Constructors.
    Public Sub New()
    End Sub
    Public Sub New(ByVal name As String, ByVal currSp As Integer)
        currSpeed = currSp
        petName = name
    End Sub

    Public Sub CrankTunes(ByVal state As Boolean)
        theMusicBox.TurnOn(state)
    End Sub

    ' See if Car has overheated.
    Public Sub Accelerate(ByVal delta As Integer)
        If carIsDead Then
            If Not (explodedList Is Nothing) Then
                explodedList("Sorry, this car is dead...")
            End If
        Else
            currSpeed += delta
            If 10 = maxSpeed - currSpeed AndAlso Not (almostDeadList Is Nothing) Then
                almostDeadList("Careful buddy!  Gonna blow!")
            End If
            If currSpeed >= maxSpeed Then
                carIsDead = True
            Else
                Console.WriteLine("->CurrSpeed = {0} ", currSpeed)
            End If
        End If
    End Sub
End Class