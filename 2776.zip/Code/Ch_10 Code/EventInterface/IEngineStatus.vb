Option Explicit On
Option Strict On

' The callback interface.
Public Interface IEngineStatus
    Sub AboutToBlow(ByVal msg As String)
    Sub Exploded(ByVal msg As String)
End Interface
