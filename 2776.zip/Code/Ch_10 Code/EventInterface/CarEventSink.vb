Option Explicit On
Option Strict On

' Car event sink.
Public Class CarEventSink
    Implements IEngineStatus
    Private name As String

    Public Sub New()
    End Sub
    Public Sub New(ByVal sinkName As String)
        name = sinkName
    End Sub

    Public Sub AboutToBlow(ByVal msg As String) Implements IEngineStatus.AboutToBlow
        Console.WriteLine("{0} reporting: {1} ", name, msg)
    End Sub
    Public Sub Exploded(ByVal msg As String) Implements IEngineStatus.Exploded
        Console.WriteLine("{0} reporting: {1} ", name, msg)
    End Sub
End Class
