Option Explicit On
Option Strict On

#Region "Person class"
' Remember! All classes implicitly derive from Object.
Class Person
    Public Sub New(ByVal firstName As String, ByVal lastName As String, _
                   ByVal age As Byte)
        fName = firstName
        lName = lastName
        personAge = age
    End Sub
    Sub New()
    End Sub

#Region "Object Overrides"
    Public Overrides Function ToString() As String
        Dim myState As String
        myState = String.Format("[First Name: {0}; Last Name: {1}; Age: {2}]", _
            fName, lName, personAge)
        Return myState
    End Function

    'Public Overrides Function Equals(ByVal obj As Object) As Boolean
    '    If TypeOf obj Is Person AndAlso obj IsNot Nothing Then
    '        Dim temp As Person
    '        temp = CType(obj, Person)
    '        If temp.fName = Me.fName AndAlso _
    '           temp.lName = Me.fName AndAlso _
    '           temp.personAge = Me.personAge Then
    '            Return True
    '        Else
    '            Return False
    '        End If
    '        Return False
    '    End If
    'End Function
    Public Overrides Function Equals(ByVal obj As Object) As Boolean
        ' No need to cast 'obj' to a Person anymore,
        ' as everyting has a ToString() method.
        Return obj.ToString = Me.ToString()
    End Function

    Public Overrides Function GetHashCode() As Integer
        Return Me.ToString().GetHashCode()
    End Function
#End Region

    ' Public only for simplicity. Properties and Private data 
    ' would obviously be perferred. 
    Public fName As String
    Public lName As String
    Public personAge As Byte
End Class
#End Region

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with System.Object *****")
        Console.WriteLine()

        '  NOTE:  We want these to be identical to test
        '  the Equals() and GetHashCode() methods.
        Dim p1 As Person = New Person("Homer", "Simpson", 50)
        Dim p2 As Person = New Person("Homer", "Simpson", 50)

        '  Get stringified version of objects.
        Console.WriteLine("p1.ToString() = {0}", p1.ToString())
        Console.WriteLine("p2.ToString() = {0}", p2.ToString())

        '  Test Overridden Equals()
        Console.WriteLine("p1 = p2?: {0}", p1.Equals(p2))

        ' Test hash codes.
        Console.WriteLine("Same hash codes?: {0}", _
          p1.GetHashCode() = p2.GetHashCode())
        Console.WriteLine()

        '  Change age of p2 and test again.
        p2.personAge = 45
        '  Get stringified version of objects.
        Console.WriteLine("p1.ToString() = {0}", p1.ToString())
        Console.WriteLine("p2.ToString() = {0}", p2.ToString())
        Console.WriteLine("p1 = p2?: {0}", p1.Equals(p2))
        Console.WriteLine("Same hash codes?: {0}", _
          p1.GetHashCode() = p2.GetHashCode())
        Console.ReadLine()

        '  Shared members of System.Object.
        Dim p3 As Person = New Person("Sally", "Jones", 4)
        Dim p4 As Person = New Person("Sally", "Jones", 4)
        Console.WriteLine("P3 and P4 have same state: {0}", Object.Equals(p3, p4))
        Console.WriteLine("P3 and P4 are pointing to same object: {0}", _
            Object.ReferenceEquals(p3, p4))
    End Sub
End Module
