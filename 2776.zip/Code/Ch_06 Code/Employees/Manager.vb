' Managers need to know their number of stock options.
Public Class Manager
    Inherits Employee
    Private numberOfOptions As Integer

    Public Sub New(ByVal fullName As String, ByVal age As Integer, _
        ByVal empID As Integer, ByVal currPay As Single, _
        ByVal ssn As String, ByVal numbOfOpts As Integer)
        ' Pass these arguments to the parent's constructor.
        MyBase.New(fullName, age, empID, currPay, ssn)

        ' This belongs with us!
        numberOfOptions = numbOfOpts
    End Sub
    Public Sub New()
    End Sub
    Public Property StockOptions() As Integer
        Get
            Return numberOfOptions
        End Get
        Set(ByVal value As Integer)
            numberOfOptions = value
        End Set
    End Property

    Public Overrides Sub GiveBonus(ByVal amount As Single)
        MyBase.GiveBonus(amount)
        Dim r As Random = New Random
        numberOfOptions += r.Next(500)
    End Sub

    Public Overrides Sub DisplayStats()
        MyBase.DisplayStats()
        Console.WriteLine("Options: {0}", numberOfOptions)
    End Sub
End Class

