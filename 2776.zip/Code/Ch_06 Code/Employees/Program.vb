Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** The Employee Class Hierarchy *****")
        Console.WriteLine()
        ' Give each employee a bonus.
        Dim chucky As New Manager("Chucky", 50, 92, 100000, "333-23-2322", 9000)
        chucky.GiveBonus(300)
        chucky.DisplayStats()
        Console.WriteLine()

        Dim fran As New SalesPerson("Fran", 43, 93, 3000, "932-32-3232", 31)
        fran.GiveBonus(200)
        fran.DisplayStats()
        Console.WriteLine()

        ' Fun with casting.
        ' A Manager "is-a" System.Object.
        Dim frank As Object = New Manager("Frank Zappa", 9, 3000, 40000, "111-11-1111", 5)

        ' A Manager "is-a" Employee too.
        Dim moonUnit As Employee = New Manager("MoonUnit Zappa", 2, 3001, _
          20000, "101-11-1321", 1)

        ' A PTSalesPerson "is-a" SalesPerson.
        Dim jill As SalesPerson = New PTSalesPerson("Jill", 834, 3002, _
          100000, "111-12-1119", 90)

        ' Streamline the staff.
        FireThisPerson(moonUnit)    ' "moonUnit" was declared as an Employee.
        Console.WriteLine()
        FireThisPerson(jill)        ' "jill" was declared as a SalesPerson.
        Console.WriteLine()
        FireThisPerson(CType(frank, Manager))    ' "frank" was declared as an Object.
        Console.ReadLine()
    End Sub

    Public Sub FireThisPerson(ByVal emp As Employee)
        If TypeOf emp Is SalesPerson Then
            Console.WriteLine("Lost a sales person named {0} ", emp.Name)
            Console.WriteLine("{0}  made {1}  sale(s)...", emp.Name, CType(emp, SalesPerson).SalesNumber)
        End If
        If TypeOf emp Is Manager Then
            Console.WriteLine("Lost a suit named {0} ", emp.Name)
            Console.WriteLine("{0}  had {1}  stock options...", emp.Name, CType(emp, Manager).StockOptions)
        End If
    End Sub

End Module
