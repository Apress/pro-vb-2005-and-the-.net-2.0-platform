Option Explicit On
Option Strict On

Public NotInheritable Class PTSalesPerson
    Inherits SalesPerson
    Public Sub New(ByVal fullName As String, ByVal age As Integer, _
    ByVal empID As Integer, ByVal currPay As Single, _
    ByVal ssn As String, ByVal numbOfSales As Integer)
        ' Pass these arguments to the parent's constructor.
        MyBase.New(fullName, age, empID, currPay, ssn, numbOfSales)
    End Sub

    ' No bonus for you!
    'Public Overrides Sub GiveBonus()
    '    ' Rats.
    'End Sub
    ' Assume other members here...
End Class
