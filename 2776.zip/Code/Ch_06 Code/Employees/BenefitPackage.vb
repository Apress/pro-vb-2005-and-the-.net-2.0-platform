Option Explicit On
Option Strict On

' This type will function as a contained class.
'Public Class BenefitPackage
'    ' Assume we have other members that represent
'    ' 401K plans,  dental / health benefits and so on.
'    Public Function ComputePayDeduction() As Double
'        Return 125.0
'    End Function
'End Class
