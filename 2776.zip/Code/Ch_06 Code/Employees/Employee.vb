Option Explicit On
Option Strict On

Partial Public MustInherit Class Employee

#Region "Nested BenefitPackage type"
    Public Class BenefitPackage
        ' Assume we have other members that represent
        ' 401K plans,  dental / health benefits and so on.
        Public Function ComputePayDeduction() As Double
            Return 125.0
        End Function

        Public Enum BenefitPackageLevel
            Standard
            Gold
            Platinum
        End Enum
    End Class
#End Region

    ' Field data.
    ' Contain a BenefitPackage object.
    Protected empBenefits As BenefitPackage = New BenefitPackage()
    Private empName As String
    Private empID As Integer
    Private currPay As Single
    Private empAge As Integer
    Private empSSN As String
    Private Shared companyName As String

    Overridable Sub GiveBonus(ByVal amount As Single)
        currPay += amount
    End Sub
    ' Expose certain benefit behaviors of object.
    Public Function GetBenefitCost() As Double
        Return empBenefits.ComputePayDeduction()
    End Function

    Overridable Sub DisplayStats()
        Console.WriteLine("Name: {0}", empName)
        Console.WriteLine("Age: {0}", empAge)
        Console.WriteLine("SSN: {0}", empSSN)
        Console.WriteLine("ID: {0}", empID)
        Console.WriteLine("Pay: {0}", currPay)
    End Sub
End Class
