Option Explicit On
Option Strict On

' Sales people need to know their number of sales.
Public Class SalesPerson
    Inherits Employee
    Private numberOfSales As Integer

    Public Sub New(ByVal fullName As String, ByVal age As Integer, _
    ByVal empID As Integer, ByVal currPay As Single, _
    ByVal ssn As String, ByVal numbOfSales As Integer)
        ' Pass these arguments to the parent's constructor.
        MyBase.New(fullName, age, empID, currPay, ssn)

        ' This belongs with us!
        numberOfSales = numbOfSales
    End Sub
    Public Sub New()
    End Sub
    Public Property SalesNumber() As Integer
        Get
            Return numberOfSales
        End Get
        Set(ByVal value As Integer)
            numberOfSales = value
        End Set
    End Property

    ' A salesperson's bonus is influenced by the number of sales.
    Public NotOverridable Overrides Sub GiveBonus(ByVal amount As Single)
        Dim salesBonus As Integer = 0
        If numberOfSales >= 0 AndAlso numberOfSales <= 100 Then
            salesBonus = 10
        Else
            If numberOfSales >= 101 AndAlso numberOfSales <= 200 Then
                salesBonus = 15
            Else
                salesBonus = 20
            End If
        End If
        MyBase.GiveBonus(amount * salesBonus)
    End Sub
    Public Overrides Sub DisplayStats()
        MyBase.DisplayStats()
        Console.WriteLine("Sales: {0}", numberOfSales)
    End Sub
End Class