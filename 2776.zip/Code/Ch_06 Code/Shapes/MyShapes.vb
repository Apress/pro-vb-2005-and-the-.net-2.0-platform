Option Explicit On
Option Strict On

#Region "Shape base class"
Public MustInherit Class Shape
    Protected shapeName As String

    Public Sub New()
        shapeName = "NoName"
    End Sub

    Public Sub New(ByVal s As String)
        shapeName = s
    End Sub

    Public MustOverride Sub Draw()

    Public Property PetName() As String
        Get
            Return shapeName
        End Get
        Set(ByVal value As String)
            shapeName = value
        End Set
    End Property
End Class
#End Region

#Region "Derived classes"
Public Class Circle
    Inherits Shape

    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Circle", shapeName)
    End Sub
End Class

Public Class Hexagon
    Inherits Shape

    Public Sub New()
    End Sub

    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Overrides Sub Draw()
        Console.WriteLine("Drawing {0} the Hexagon", shapeName)
    End Sub
End Class

' This class extends Circle and hides the inherited Draw() method.
Public Class ThreeDCircle
    Inherits Circle

    ' Hide the shapeName field above me.
    Protected Shadows shapeName As String

    ' Hide any Draw() implementation above me.
    Public Shadows Sub Draw()
        Console.WriteLine("Drawing a 3D Circle")
    End Sub
End Class
#End Region
