Option Explicit On
Option Strict On

Module Program

    Sub Main()
        Console.WriteLine("***** Basic Inheritance Example ******")
        Console.WriteLine()

        ' Make a Car type.
        Dim myCar As New Car(80)
        myCar.Speed = 50
        Console.WriteLine("My car is going {0} MPH", _
          myCar.Speed)
    End Sub

End Module
