Option Explicit On
Option Strict On

Imports System.Windows.Forms
Imports CommonSnappableTypes
Imports System.Reflection

Public Class MainForm
    Sub New()
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        CenterToScreen()
    End Sub

    Private Sub SnapInModuleToolStripMenuItem_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles SnapInModuleToolStripMenuItem.Click
        ' Allow user to select an assembly to load.
        Dim dlg As OpenFileDialog = New OpenFileDialog()

        If dlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            If LoadExternalModule(dlg.FileName) = False Then
                MessageBox.Show("Nothing implements IAppFunctionality!")
            End If
        End If
    End Sub

    Private Function LoadExternalModule(ByVal path As String) As Boolean
        Dim foundSnapIn As Boolean = False
        Dim itfAppFx As IAppFunctionality

        ' Dynamically load the selected assembly.
        Dim theSnapInAsm As Assembly = Assembly.LoadFrom(path)

        ' Get all types in assembly.
        Dim theTypes As Type() = theSnapInAsm.GetTypes()

        For i As Integer = 0 To UBound(theTypes)
            ' See if a type implement IAppFunctionality.
            Dim t As Type = theTypes(i).GetInterface("IAppFunctionality")
            If Not (t Is Nothing) Then
                foundSnapIn = True

                ' Use late binding to create the type.
                Dim o As Object = theSnapInAsm.CreateInstance(theTypes(i).FullName)

                ' Call DoIt() off the interface.
                itfAppFx = CType(o, IAppFunctionality)
                itfAppFx.DoIt()
                lstLoadedSnapIns.Items.Add(theTypes(i).FullName)

                ' Show company info.
                DisplayCompanyData(theTypes(i))
            End If
        Next
        Return foundSnapIn
    End Function

    Private Sub DisplayCompanyData(ByVal t As Type)
        ' Get <CompanyInfo> data.
        Dim customAtts As Object() = t.GetCustomAttributes(False)
        For Each c As CompanyInfoAttribute In customAtts
            ' Show data.
            MessageBox.Show(c.Url, String.Format("More info about {0} can be found at", c.Name))
        Next
    End Sub
End Class
