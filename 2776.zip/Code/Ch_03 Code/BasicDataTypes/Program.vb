Option Explicit On
Option Strict On

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Data Types *****")

        ' A VB 2005 Integer is really a shorthand for System.Int32.
        ' which inherits the following members from System.Object.
        Console.WriteLine(12.GetHashCode())
        Console.WriteLine(12.Equals(23))
        Console.WriteLine(12.ToString())
        Console.WriteLine(12.GetType())
        Console.WriteLine()

        ' The Integer exposed!
        Console.WriteLine("Max of Integer: {0}", Integer.MaxValue)
        Console.WriteLine("Min of Integer: {0}", Integer.MinValue)
        Console.WriteLine()

        ' The Double exposed!
        Console.WriteLine("Max of Double: {0}", Double.MaxValue)
        Console.WriteLine("Min of Double: {0}", Double.MinValue)
        Console.WriteLine("Double.Epsilon: {0}", Double.Epsilon)
        Console.WriteLine("Double.PositiveInfinity: {0}", Double.PositiveInfinity)
        Console.WriteLine("Double.NegativeInfinity: {0}", Double.NegativeInfinity)
        Console.WriteLine()

        ' The Boolean exposed!
        Console.WriteLine("Boolean.FalseString: {0}", Boolean.FalseString)
        Console.WriteLine("Boolean.TrueString: {0}", Boolean.TrueString)
        Console.WriteLine()

        ' The Char exposed!
        Dim myChar As Char = "a"c
        Console.WriteLine("Char.IsDigit('a'): {0} ", Char.IsDigit(myChar))
        Console.WriteLine("Char.IsLetter('a'): {0} ", Char.IsLetter(myChar))
        Console.WriteLine("Char.IsWhiteSpace('Hello There', 5): {0}", _
         Char.IsWhiteSpace("Hello There", 5))
        Console.WriteLine("Char.IsWhiteSpace('Hello There', 6): {0}", _
         Char.IsWhiteSpace("Hello There", 6))
        Console.WriteLine("Char.IsPunctuation('?'): {0}", _
            Char.IsPunctuation("?"c))
        Console.WriteLine()

        ' Fun with parsing
        Dim b As Boolean = Boolean.Parse("True")
        Console.WriteLine("-> Value of myBool: {0}", b)
        Dim d As Double = Double.Parse("99.884")
        Console.WriteLine("-> Value of myDbl: {0}", d)
        Dim i As Integer = Integer.Parse("8")
        Console.WriteLine("-> Value of myInt: {0}", i)
        Dim c As Char = Char.Parse("w")
        Console.WriteLine("-> Value of myChar: {0}", c)
    End Sub
End Module
