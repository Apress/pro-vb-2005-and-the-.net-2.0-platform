Option Explicit On
Option Strict On

Module Program

#Region "Main method"
    Sub Main()
        ' Show banner.
        DisplayBanner()
        ' GreetUser()

        ' Call second form of GreetUser().
        userName = "Fred"
        MyModule.GreetUser()

        ' Add some numbers.
        ' (module prefix optional)
        Console.WriteLine("10 + 10 is {0}.", Add(10, 10))

        ' Subtract some numbers 
        ' (module prefix optional)
        Console.WriteLine("10 - 10 is {0}.", MyMathModule.Subtract(10, 10))
        Console.ReadLine()
    End Sub
#End Region

    Sub DisplayBanner()
        Console.ForegroundColor = ConsoleColor.Yellow
        Console.WriteLine("******* Welcome to FunWithModules *******")
        Console.WriteLine("This simple program illustrates the role")
        Console.WriteLine("of the VB 2005 Module type.")
        Console.WriteLine("*****************************************")
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine()
    End Sub

    Sub GreetUser()
        Dim userName As String
        Console.Write("Please enter your name: ")
        userName = Console.ReadLine()
        Console.WriteLine("Hello there {0}.  Nice to meet ya.", userName)
    End Sub
End Module

#Region "MyMathModule"
Module MyMathModule
    Function Add(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x + y
    End Function
    Function Subtract(ByVal x As Integer, ByVal y As Integer) As Integer
        Return x - y
    End Function
End Module
#End Region

#Region "MyModule"
Module MyModule
    Public userName As String

    Sub GreetUser()
        Console.WriteLine("Hello, {0}.", userName)
    End Sub
End Module
#End Region