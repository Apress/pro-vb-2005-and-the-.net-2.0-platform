Option Explicit On
Option Strict On

Imports System.Text

Module Program
    Sub Main()
        Console.WriteLine("***** Fun with Strings *****")
        Console.WriteLine()

        ' Basic Sting stuff.
        Console.WriteLine("* Basic String Stuff *")
        Dim firstName As String = "June"
        Console.WriteLine("Value of firstName: {0}", firstName)
        Console.WriteLine("firstName has {0} characters.", firstName.Length)
        Console.WriteLine("firstName in uppercase: {0}", firstName.ToUpper())
        Console.WriteLine("firstName in lowercase: {0}", firstName.ToLower())
        Dim myValue As Integer = 3456787
        Console.WriteLine("Hex vaule of myValue is: {0}", _
          String.Format("{0:X}", myValue))
        Console.WriteLine("Currency vaule of myValue is: {0}", _
          String.Format("{0:C}", myValue))
        Console.WriteLine()

        ' Concatenation.
        Console.WriteLine("* Concatenation *")
        Dim s1 As String = "Programming the "
        Dim s2 As String = "PsychoDrill (PTP)"
        ' Dim s3 As String = s1 & s2

        Dim s3 As String = String.Concat(s1, s2)
        Console.WriteLine(s3)
        Console.WriteLine()

        ' Equality of string object. 
        Console.WriteLine("* Equality *")
        Dim strA As String = "Hello!"
        Dim strB As String = "Yo!"
        ' False!
        Console.WriteLine("strA = strB?: {0}", strA = strB)
        strB = "HELLO!"
        ' False!
        Console.WriteLine("strA = strB?: {0}", strA = strB)
        strB = "Hello!"
        ' True!
        Console.WriteLine("strA = strB?: {0}", strA = strB)
        Console.WriteLine()

        ' Strings are immutable!
        ' Set initial string value
        Console.WriteLine("* Strings are immutable! *")
        Dim initialString As String = "This is my string."
        Console.WriteLine("Initial value: {0}", initialString)

        ' Upper case the initialString?
        Dim upperString As String = initialString.ToUpper()
        Console.WriteLine("Upper case copy: {0}", upperString)

        ' Nope!  initialString is in the same format.
        Console.WriteLine("Initial value: {0}", initialString)
        Console.WriteLine()

        ' StringBuilder.
        Dim sb As New StringBuilder("**** Fantastic Games ****", 256)
        sb.Append(vbLf)
        sb.AppendLine("Half Life 2")
        sb.AppendLine("Beyond Good and Evil")
        sb.AppendLine("Deus Ex 1 and 2")
        sb.Append("System Shock")
        sb.Replace("2", "Deus Ex: Invisible War")
        Console.WriteLine(sb) ' ToString() called automatically here. 
        Console.WriteLine("sb has {0} chars.", sb.Length)
    End Sub
End Module



